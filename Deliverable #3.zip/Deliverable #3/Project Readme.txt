3D Mini-Modelling:
Allow users to create, edit, and view objects in 3D.
Specifically, allow users to add points, lines and polygons to screen to form 3D objects
and modify these objects.

*Requirements: Have the following files in the same directory

1. Line.py
2. Main.py
3. MyButton.py
4. Point.py
5. Polygon.py
6. Utility.py

To run the project, open Main.py